﻿using System;
namespace Projet_Isi.Models.Metier
{
    public class Utilisateur
    {
        private int id_utilisateur;
        private string nom_utilisateur;
        private string mot_de_passe;
        private bool est_professeur;
        // Ajoutez d'autres propriétés pour les utilisateurs selon vos besoins

        public int Id_utilisateur { get => id_utilisateur; set => id_utilisateur = value; }
        public string Nom_utilisateur { get => nom_utilisateur; set => nom_utilisateur = value; }
        public string Mot_de_passe { get => mot_de_passe; set => mot_de_passe = value; }
        public bool Est_professeur { get => est_professeur; set => est_professeur = value; }
        // Ajoutez d'autres propriétés pour les utilisateurs selon vos besoins
    }
}

