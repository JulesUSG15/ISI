﻿using System;
namespace Projet_Isi.Models.Metier
{
    public class Etudiant
    {
        private int id_etudiant;
        private string nom;
        // Ajoutez d'autres propriétés pour les étudiants selon vos besoins

        public int Id_etudiant { get => id_etudiant; set => id_etudiant = value; }
        public string Nom { get => nom; set => nom = value; }
        // Ajoutez d'autres propriétés pour les étudiants selon vos besoins
    }
}
