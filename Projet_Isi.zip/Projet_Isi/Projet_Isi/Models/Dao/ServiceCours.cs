﻿using System.Data;
using Projet_Isi.Models.Persistance;
using Projet_Isi.Models.MesExceptions;


namespace Projet_Isi.Models.Dao
{
    public class ServiceCours
    {
        public static DataTable GetTousLesCours()
        {
            DataTable Cours;
            Serreurs er = new Serreurs("Erreur sur lecture des Cours.", "Cours.getCours()");

            String mysql = "Select id_cours, nom, description, nom_prof, duree, date ";
            mysql += "from Cours ";

            Cours = DBInterface.Lecture(mysql, er);

            try
            {
                 mysql = "Select id_cours, nom, description, nom_prof, duree, date ";
                mysql += "from Cours ";

                Cours = DBInterface.Lecture(mysql, er);

                return Cours;
            }
            catch (MonException e)
            {
                throw new MonException(er.MessageUtilisateur(), er.MessageUtilisateur(), e.Message);
            }

        }

        public static DataTable GetUnCours(int idCours)
        {
            DataTable Cours;
            Serreurs er = new Serreurs("Erreur sur lecture d'un cours.", "Cours.getUnCours()");
            try
            {
                String mysql = $"SELECT id_cours, nom, description, nom_prof, duree, date FROM Cours WHERE id_cours = {idCours}";

                Cours = DBInterface.Lecture(mysql, er);

                return Cours;
            }
            catch (MonException e)
            {
                throw new MonException(er.MessageUtilisateur(), er.MessageUtilisateur(), e.Message);
            }
        }
    }
}
