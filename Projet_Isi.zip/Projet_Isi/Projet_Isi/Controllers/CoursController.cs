﻿using Microsoft.AspNetCore.Mvc;
using Projet_Isi.Models.Dao;
using Projet_Isi.Models.MesExceptions;

namespace Projet_Isi.Controllers
{ 
    public class CoursController : Controller
    {
        public IActionResult Index()
        {
            System.Data.DataTable Cours = null;
            Cours = ServiceCours.GetTousLesCours();
            try
            {
                Cours = ServiceCours.GetTousLesCours();

            }
            catch (MonException e)
            {
                ModelState.AddModelError("Erreur", "Erreur lors de la récupération des Cours:" + e.Message);
            }

            return View(Cours);
        }

        // Autres actions pour l'inscription, la modification, etc.
    }

}
