﻿using Microsoft.AspNetCore.Mvc;
using Projet_Isi.Models.Dao;
using Projet_Isi.Models.MesExceptions;

namespace Projet_Isi.Controllers
{
    public class RessourcesController : Controller
    {
        public IActionResult Index()
        {
            System.Data.DataTable Ressources = null;

            try
            {
                Ressources = ServiceRessource.GetToutesRessources();

            }
            catch (MonException e)
            {
                ModelState.AddModelError("Erreur", "Erreur lors de la récupération des Ressources:" + e.Message);
            }

            return View(Ressources);
        }
    }
}

